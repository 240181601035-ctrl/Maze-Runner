# AI Maze Runner — Python Pathfinding Game

A desktop maze game built with Python and Tkinter. Navigate the maze yourself or let the AI find a shortest path using the **A\* (A-star) search algorithm**.

## Features
- Random maze generation using recursive backtracking
- Player movement with arrow keys or W/A/S/D
- A* AI solver with visible explored cells and shortest path
- Move counter and timer
- New maze and clear-path controls
- No third-party Python packages required

## Requirements
- Python 3.8 or later
- Tkinter (included with most standard Python installations)

## Run
```bash
python main.py
```

## Controls
- Arrow keys / W A S D: move the player
- NEW MAZE: generate another maze
- AI SOLVE: show the AI's shortest path from your current position
- CLEAR PATH: remove the AI visualization

## AI concept
A* evaluates each cell using:

`f(n) = g(n) + h(n)`

- `g(n)`: cost from the start cell to the current cell
- `h(n)`: estimated cost from the current cell to the goal (Manhattan distance)
- `f(n)`: total estimated path cost

The algorithm uses a priority queue to explore the most promising cell first. With unit movement costs and the Manhattan heuristic, A* finds a shortest path in this four-direction maze.

## Files
- `main.py` — game, maze generation, player controls and A* algorithm
- `REPORT.md` — assessment report template
