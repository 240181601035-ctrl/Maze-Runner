# PROJECT REPORT
## AI MAZE RUNNER: INTELLIGENT PATHFINDING USING A* ALGORITHM

**Subject:** Artificial Intelligence and Machine Learning  
**Project Type:** Assessment Component / Mini Project  
**Programming Language:** Python

---

## ABSTRACT

AI Maze Runner is a Python-based maze game that demonstrates Artificial Intelligence through the A* search algorithm. The player can move through a randomly generated maze using keyboard controls. The AI solver can also search for a path from the player's current position to the exit. The game displays the explored cells and the path found by the algorithm. This project provides a practical demonstration of search and pathfinding techniques used in Artificial Intelligence.

## 1. INTRODUCTION

Artificial Intelligence helps computers solve problems and make decisions. Pathfinding is an important AI application used in maps, robotics and games. This project creates a maze in which a player must reach an exit. The A* algorithm is used by the computer to find a shortest route through the available paths.

## 2. OBJECTIVES

- To develop an interactive maze game using Python.
- To understand the A* search algorithm.
- To demonstrate intelligent pathfinding.
- To generate random mazes.
- To display the path found by the AI.

## 3. REQUIREMENTS

### Hardware
- Desktop computer or laptop
- Keyboard and mouse
- Minimum 2 GB RAM

### Software
- Python 3.8 or later
- Tkinter GUI library
- Code editor such as Visual Studio Code (optional)

## 4. SYSTEM DESIGN

The system has four main modules:

1. **Maze Generator:** Creates a random maze using recursive backtracking.
2. **Player Control:** Allows movement using arrow keys or W, A, S and D.
3. **A* Search Engine:** Finds a shortest path from the player's position to the exit.
4. **Game Interface:** Displays the maze, player, exit, timer, moves and AI path.

### Working Procedure

1. Start the application.
2. Generate a random maze.
3. Place the player at the starting cell and the exit at the goal cell.
4. The player moves through open cells using the keyboard.
5. When AI SOLVE is selected, A* searches for a path.
6. Display the explored cells and the path to the exit.
7. The player can generate a new maze and play again.

## 5. ALGORITHM USED — A* SEARCH

A* is an informed search algorithm used to find a low-cost path from a start node to a goal node.

The evaluation formula is:

**f(n) = g(n) + h(n)**

Where:
- `g(n)` is the actual cost from the start to the current cell.
- `h(n)` is the estimated cost from the current cell to the goal.
- `f(n)` is the estimated total cost of the path through that cell.

This project uses Manhattan distance:

**h(n) = |row1 - row2| + |column1 - column2|**

### Steps

1. Add the starting cell to a priority queue.
2. Select the cell with the lowest f-score.
3. Check its neighbouring cells.
4. Ignore walls and already processed cells.
5. Calculate the cost of each valid neighbour.
6. Update the best known path and add the neighbour to the queue.
7. Continue until the goal is reached or no path remains.
8. Reconstruct and display the path.

## 6. IMPLEMENTATION

The project is implemented in one Python file, `main.py`.

- Tkinter is used to create the graphical interface.
- Random and recursive backtracking are used to generate the maze.
- Heapq provides the priority queue for A*.
- The time module is used for the game timer.
- The A* algorithm calculates and displays the path to the exit.

## 7. OUTPUT

The application displays:
- A randomly generated maze.
- A player marker and a goal marker.
- A move counter and timer.
- The cells explored by the AI.
- The shortest path found by the AI.

### Test Cases

| Test | Action | Expected Result |
|---|---|---|
| 1 | Start the program | A new maze is displayed |
| 2 | Move into an open cell | Player moves one cell |
| 3 | Try to move into a wall | Player remains in the same cell |
| 4 | Select AI SOLVE | A* path is displayed |
| 5 | Select NEW MAZE | A different maze is generated |
| 6 | Reach the exit | Completion message is displayed |

## 8. ADVANTAGES

- Easy to play and understand.
- Demonstrates a real AI search algorithm.
- Generates different mazes.
- Finds a shortest path for the given movement rules.
- Does not require paid APIs or external packages.

## 9. LIMITATIONS

- The AI uses pathfinding and does not learn from experience.
- The maze uses four-direction movement only.
- The game is designed for a single player.
- The maze size is fixed in the source code.

## 10. CONCLUSION

AI Maze Runner demonstrates the use of Artificial Intelligence in pathfinding. The A* algorithm explores possible routes and finds a shortest path from the player's current position to the exit. The project combines Python programming, graphical interface design, maze generation and intelligent search. It provides a practical introduction to AI search algorithms.

## 11. REFERENCES

1. Stuart Russell and Peter Norvig, *Artificial Intelligence: A Modern Approach*.
2. Python documentation: https://docs.python.org/3/
3. Tkinter documentation: https://docs.python.org/3/library/tkinter.html
4. A* search algorithm: https://en.wikipedia.org/wiki/A*_search_algorithm

---

**Before submission:** Add your name, register number, department, college name and faculty name. Run the program and insert screenshots of the game and AI solution in the output section.
