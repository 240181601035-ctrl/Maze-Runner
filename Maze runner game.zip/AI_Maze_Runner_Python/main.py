"""
AI MAZE RUNNER
A Python maze game demonstrating A* pathfinding.
Run: python main.py
Requires: Python 3.x (Tkinter is included with most Python installations).
"""

import tkinter as tk
from tkinter import messagebox
import random
import heapq
import time

ROWS, COLS = 15, 21
CELL = 30
WALL, OPEN = 1, 0

BG = "#0b1020"
PANEL = "#121c30"
WALL_COLOR = "#263650"
PATH_COLOR = "#e8eef8"
PLAYER_COLOR = "#45d6e8"
GOAL_COLOR = "#54df9b"
AI_COLOR = "#f4bd50"
VISITED_COLOR = "#243f59"

class MazeRunner:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Maze Runner | A* Pathfinding")
        self.root.configure(bg=BG)
        self.root.resizable(False, False)

        self.maze = []
        self.player = (1, 1)
        self.goal = (ROWS - 2, COLS - 2)
        self.ai_path = []
        self.visited = set()
        self.moves = 0
        self.started_at = time.time()
        self.finished = False

        self.build_ui()
        self.new_maze()
        self.root.bind("<Up>", lambda e: self.move_player(-1, 0))
        self.root.bind("<Down>", lambda e: self.move_player(1, 0))
        self.root.bind("<Left>", lambda e: self.move_player(0, -1))
        self.root.bind("<Right>", lambda e: self.move_player(0, 1))
        self.root.bind("w", lambda e: self.move_player(-1, 0))
        self.root.bind("s", lambda e: self.move_player(1, 0))
        self.root.bind("a", lambda e: self.move_player(0, -1))
        self.root.bind("d", lambda e: self.move_player(0, 1))
        self.update_timer()

    def build_ui(self):
        title = tk.Label(self.root, text="AI MAZE RUNNER", bg=BG, fg=PLAYER_COLOR,
                         font=("Arial", 22, "bold"))
        title.pack(pady=(15, 2))
        subtitle = tk.Label(self.root, text="FIND THE EXIT  •  POWERED BY A* SEARCH",
                            bg=BG, fg="#91a4bd", font=("Arial", 9, "bold"))
        subtitle.pack(pady=(0, 12))

        self.canvas = tk.Canvas(self.root, width=COLS * CELL, height=ROWS * CELL,
                                bg=BG, highlightthickness=0)
        self.canvas.pack(padx=16, pady=5)

        stats = tk.Frame(self.root, bg=PANEL, padx=12, pady=10)
        stats.pack(fill="x", padx=16, pady=10)

        self.moves_label = tk.Label(stats, text="MOVES  0", bg=PANEL, fg="white",
                                    font=("Arial", 10, "bold"))
        self.moves_label.pack(side="left", padx=8)
        self.time_label = tk.Label(stats, text="TIME  00:00", bg=PANEL, fg="white",
                                   font=("Arial", 10, "bold"))
        self.time_label.pack(side="left", padx=15)
        self.status_label = tk.Label(stats, text="Reach the green exit!",
                                     bg=PANEL, fg=GOAL_COLOR, font=("Arial", 10))
        self.status_label.pack(side="right", padx=8)

        controls = tk.Frame(self.root, bg=BG)
        controls.pack(pady=(2, 14))
        self.make_button(controls, "NEW MAZE", self.new_maze).pack(side="left", padx=5)
        self.make_button(controls, "AI SOLVE", self.solve_with_ai, accent=True).pack(side="left", padx=5)
        self.make_button(controls, "CLEAR PATH", self.clear_ai).pack(side="left", padx=5)

        hint = tk.Label(self.root, text="MOVE WITH ARROW KEYS OR W A S D  |  AI SOLVE SHOWS THE SHORTEST PATH",
                        bg=BG, fg="#71839d", font=("Arial", 8))
        hint.pack(pady=(0, 12))

    def make_button(self, parent, text, command, accent=False):
        return tk.Button(parent, text=text, command=command, bg=PLAYER_COLOR if accent else PANEL,
                         fg=BG if accent else "white", activebackground="#79e9f0",
                         activeforeground=BG, relief="flat", bd=0,
                         font=("Arial", 9, "bold"), padx=13, pady=9, cursor="hand2")

    def generate_maze(self):
        # Recursive backtracking maze generation.
        grid = [[WALL for _ in range(COLS)] for _ in range(ROWS)]
        start = (1, 1)
        grid[1][1] = OPEN
        stack = [start]
        directions = [(0, 2), (0, -2), (2, 0), (-2, 0)]

        while stack:
            r, c = stack[-1]
            options = []
            for dr, dc in directions:
                nr, nc = r + dr, c + dc
                if 1 <= nr < ROWS - 1 and 1 <= nc < COLS - 1 and grid[nr][nc] == WALL:
                    options.append((nr, nc, dr, dc))
            if options:
                nr, nc, dr, dc = random.choice(options)
                grid[r + dr // 2][c + dc // 2] = OPEN
                grid[nr][nc] = OPEN
                stack.append((nr, nc))
            else:
                stack.pop()

        # Open a few extra cells to create alternative routes.
        for _ in range(18):
            r = random.randrange(1, ROWS - 1)
            c = random.randrange(1, COLS - 1)
            if r % 2 == 1 or c % 2 == 1:
                grid[r][c] = OPEN

        grid[1][1] = OPEN
        grid[ROWS - 2][COLS - 2] = OPEN
        return grid

    def new_maze(self):
        self.maze = self.generate_maze()
        self.player = (1, 1)
        self.goal = (ROWS - 2, COLS - 2)
        self.ai_path = []
        self.visited = set()
        self.moves = 0
        self.started_at = time.time()
        self.finished = False
        self.moves_label.config(text="MOVES  0")
        self.status_label.config(text="Reach the green exit!", fg=GOAL_COLOR)
        self.draw_maze()

    def draw_maze(self):
        self.canvas.delete("all")
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL, r * CELL
                x2, y2 = x1 + CELL, y1 + CELL
                color = WALL_COLOR if self.maze[r][c] == WALL else PATH_COLOR
                if (r, c) in self.visited and self.maze[r][c] == OPEN:
                    color = VISITED_COLOR
                self.canvas.create_rectangle(x1, y1, x2, y2, fill=color,
                                              outline=BG, width=1)

        for r, c in self.ai_path:
            self.canvas.create_rectangle(c * CELL + 7, r * CELL + 7,
                                         (c + 1) * CELL - 7, (r + 1) * CELL - 7,
                                         fill=AI_COLOR, outline="")

        gr, gc = self.goal
        self.canvas.create_oval(gc * CELL + 5, gr * CELL + 5,
                                (gc + 1) * CELL - 5, (gr + 1) * CELL - 5,
                                fill=GOAL_COLOR, outline="")
        pr, pc = self.player
        self.canvas.create_oval(pc * CELL + 5, pr * CELL + 5,
                                (pc + 1) * CELL - 5, (pr + 1) * CELL - 5,
                                fill=PLAYER_COLOR, outline="white", width=2)

    def move_player(self, dr, dc):
        if self.finished:
            return
        nr, nc = self.player[0] + dr, self.player[1] + dc
        if 0 <= nr < ROWS and 0 <= nc < COLS and self.maze[nr][nc] == OPEN:
            self.player = (nr, nc)
            self.moves += 1
            self.ai_path = []
            self.moves_label.config(text=f"MOVES  {self.moves}")
            if self.player == self.goal:
                self.finished = True
                self.status_label.config(text="YOU ESCAPED! Great job.", fg=GOAL_COLOR)
                messagebox.showinfo("Maze complete", f"You reached the exit in {self.moves} moves!")
            self.draw_maze()

    @staticmethod
    def heuristic(a, b):
        # Manhattan distance for movement in four directions.
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def a_star(self):
        start, goal = self.player, self.goal
        frontier = [(0, start)]
        came_from = {start: None}
        cost_so_far = {start: 0}
        explored = set()

        while frontier:
            _, current = heapq.heappop(frontier)
            if current in explored:
                continue
            explored.add(current)

            if current == goal:
                break

            r, c = current
            for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                nxt = (r + dr, c + dc)
                nr, nc = nxt
                if 0 <= nr < ROWS and 0 <= nc < COLS and self.maze[nr][nc] == OPEN:
                    new_cost = cost_so_far[current] + 1
                    if nxt not in cost_so_far or new_cost < cost_so_far[nxt]:
                        cost_so_far[nxt] = new_cost
                        priority = new_cost + self.heuristic(nxt, goal)
                        heapq.heappush(frontier, (priority, nxt))
                        came_from[nxt] = current

        if goal not in came_from:
            return [], explored

        path = []
        current = goal
        while current is not None:
            path.append(current)
            current = came_from[current]
        path.reverse()
        return path, explored

    def solve_with_ai(self):
        path, explored = self.a_star()
        self.visited = explored
        self.ai_path = path[1:] if path else []
        if path:
            self.status_label.config(text=f"AI found a path: {len(path) - 1} steps", fg=AI_COLOR)
        else:
            self.status_label.config(text="No path found.", fg="#ff7777")
        self.draw_maze()

    def clear_ai(self):
        self.ai_path = []
        self.visited = set()
        self.status_label.config(text="AI path cleared. Your turn!", fg=GOAL_COLOR)
        self.draw_maze()

    def update_timer(self):
        if not self.finished:
            elapsed = int(time.time() - self.started_at)
            self.time_label.config(text=f"TIME  {elapsed // 60:02d}:{elapsed % 60:02d}")
        self.root.after(500, self.update_timer)


if __name__ == "__main__":
    window = tk.Tk()
    game = MazeRunner(window)
    window.mainloop()
